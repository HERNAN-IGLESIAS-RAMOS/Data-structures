package estdatos;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class OpenHash<E> extends AbstractSet<E> implements Set<E> {

	private List<SortedSet<E>> table;
	private int elements;
	private int tablesize;
	private double loadFactorLimit;

	public OpenHash() {
		this(11, 0.75);
	}

	public OpenHash(int initialCapacity) {
		this(initialCapacity, 0.75);
	}

	public OpenHash(int initialCapacity, double theLoadFactor) {
		if (initialCapacity <= 0 || theLoadFactor <= 0) {
			throw new IllegalArgumentException();
		}

		this.tablesize = initialCapacity;
		this.loadFactorLimit = theLoadFactor;
		this.table = new ArrayList<>(initialCapacity);
		for (int i = 0; i < initialCapacity; i++) {
			this.table.add(new TreeSet<>());
		}

		this.elements = 0;

	}

	public OpenHash(Collection<? extends E> c) {
		this();
		this.addAll(c);
	}

	@SuppressWarnings("unused")
	private int hash(E e) {
		return e.hashCode() % tablesize;
	}

	@Override
	public int size() {
		return this.elements;
	}

	@Override
	public Iterator<E> iterator() {
		return new OpenHashIterator();
	}

	private class OpenHashIterator implements Iterator {

		private int pos;
		private Iterator<E> itr;
		private E lastReturned;

		

		private Iterator<E> getFirstIterator() {

			while (pos < tablesize) {
				itr = table.get(pos).iterator();
				if (itr.hasNext()) {
					return itr;
				}

			}
			return null;
		}
		
		public OpenHashIterator() {
			pos = 0;
			itr = getFirstIterator();
			lastReturned=null;
		}

		@Override
		public boolean hasNext() {
			if (itr != null && itr.hasNext()) {
				return true;
			}
			itr = getFirstIterator();
			return itr != null;
		}

		@Override
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			lastReturned = itr.next();
			return lastReturned;
		}

		@Override
		public void remove() {
			if (lastReturned == null) {
				throw new NoSuchElementException();
			}
			itr.remove();
			lastReturned = null;
			elements--;
		}

	}

	public int tablesize() {
		return this.tablesize;
	}

	public String printTable() {
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < tablesize; i++) {
			result.append("").append(i).append(": ");
			result.append(table.get(i)).append("\n");
		}
		return result.toString();
	}
	
	//otra version
	/*
	 * 
	 * 
	 * String result = new String();
	 * for(int i=0;i<tablesize;i++)
	 * result=i+": ";
	 * for(E elemn: table.get(i))
	 * 	result += elemn+" ";
	 * 
	 * result+="\n"
	 * 
	 * return result;
	 * 
	 * 
	 * 
	 */

	private void resize(int newCapacity) {
		OpenHash<E> aux = new OpenHash<E>(newCapacity);
		aux.addAll(this);
		tablesize = newCapacity;
		table = aux.table;
	}

	@Override
	public boolean add(E e) {

		int index = hash((E) e);
		boolean added = table.get(index).add(e);
		if (added) {
			this.elements++;
			if (elements > tablesize * loadFactorLimit) {
				int newCapacity = tablesize * 2;
				resize(newCapacity);
			}
			return true;
		}

		return false;
	}

	@Override
	public boolean contains(Object o) {
		int index = hash((E) o);
		return table.get(index).contains(o);

	}

	@Override
	public boolean remove(Object o) {

		int index = hash((E) o);
		boolean removed = table.get(index).remove(o);
		if (removed) {
			this.elements--;
			return true;
		}

		return false;
	}

}
